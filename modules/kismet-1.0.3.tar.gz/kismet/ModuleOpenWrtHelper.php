<?php
/*
 * Project: Frieren Framework
 * Copyright (C) 2026 nullbytes <nullbytesX00@icloud.com>
 * SPDX-License-Identifier: LGPL-3.0-only
 * More info at: https://github.com/xchwarze/frieren
 */

namespace frieren\modules\kismet;

/**
 * Helper class for the OpenWrt platform.
 */
class ModuleOpenWrtHelper
{
    /**
     * Lists kernel network interfaces (wired + wireless), for the capture-interface
     * picker. Mirrors the pattern used by hcxdumptool/tcpdump's own module helpers.
     *
     * @return string[] Interface names, or empty array on failure.
     */
    public static function getNetworkInterfaces()
    {
        $interfaces = scandir('/sys/class/net/');
        if ($interfaces === false) {
            return [];
        }

        return array_values(array_diff($interfaces, ['.', '..']));
    }
}
